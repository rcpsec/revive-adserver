<?php

class area_hollow extends area_base
{
	function __construct()
	{
		$this->type      = "area_hollow";
		parent::__construct();
	}
}
