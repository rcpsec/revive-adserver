<?php

class radar_spoke_labels
{
	// $labels : array
	function __construct( $labels )
	{
		$this->labels = $labels;
	}
	
	function set_colour( $colour )
	{
		$this->colour = $colour;
	}
}