<?php

/*
+---------------------------------------------------------------------------+
| Revive Adserver                                                           |
| http://www.revive-adserver.com                                            |
|                                                                           |
| Copyright: See the COPYRIGHT.txt file.                                    |
| License: GPLv2 or later, see the LICENSE.txt file.                        |
+---------------------------------------------------------------------------+
*/

$words =  array(
    'Local Mode Tag' => 'Etiqueta en Modo Local',
    'Allow Local Mode Tags' => 'Permitir etiquetas en Modo Local',
    'Assign the $phpAds_raw[\'html\'] variable to your template' => 'Asignar la variable \$phpAds_raw[\'html\'] a su template',
);

?>