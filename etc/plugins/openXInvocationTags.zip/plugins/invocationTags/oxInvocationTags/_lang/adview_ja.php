<?php

/*
+---------------------------------------------------------------------------+
| Revive Adserver                                                           |
| http://www.revive-adserver.com                                            |
|                                                                           |
| Copyright: See the COPYRIGHT.txt file.                                    |
| License: GPLv2 or later, see the LICENSE.txt file.                        |
+---------------------------------------------------------------------------+
*/

$words = array(
    'Image Tag' => 'イメージタグ',
    'Allow Image Tags' => 'イメージタグを許可する',
    'SSL Backup Comment' => '',
    'Comment' => "
  * このタグはイメージバナーだけを表示します。その際、表示するイメージバナーは幅か高さが指定さ
  * れないため、イメージバナー表示用にこのタグを配置する場合、<img>タグ内で幅や高さを必ず指
  * 定してください。
  * ",
    'Third Party Comment' => '',
);

?>
