<?php

/*
+---------------------------------------------------------------------------+
| Revive Adserver                                                           |
| http://www.revive-adserver.com                                            |
|                                                                           |
| Copyright: See the COPYRIGHT.txt file.                                    |
| License: GPLv2 or later, see the LICENSE.txt file.                        |
+---------------------------------------------------------------------------+
*/

$conf = $GLOBALS['_MAX']['CONF'];

$words =  array(
    'Javascript Tag' => 'Etiqueta Javascript',
    'Allow Javascript Tags' => 'Permitir Javascript',
    'Insert click tracking URL here' => 'Insertar URL a rastrear aquí',
);

?>
